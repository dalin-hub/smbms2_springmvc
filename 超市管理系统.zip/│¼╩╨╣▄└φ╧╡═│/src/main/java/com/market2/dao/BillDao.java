package com.market2.dao;

import com.market2.pojo.Bill;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BillDao {
    List<Bill> getBills(@Param("productName") String productName,
                        @Param("providerId") Integer providerId,
                        @Param("isPayment") Integer isPayment);

    Bill getBillById(Integer id);

    void updateBill(Bill bill);

    void addBill(Bill bill);
}
