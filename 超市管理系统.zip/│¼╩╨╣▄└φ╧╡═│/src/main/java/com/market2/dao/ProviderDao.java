package com.market2.dao;

import com.market2.pojo.Provider;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProviderDao {
    List<Provider> getProviders(@Param("proCode") String proCode, @Param("proName") String proName);

    Provider getProviderById(@Param("id") Integer proId);

    void updateProvider(Provider provider);

    void delProviderById(String id);

    void addProvider(Provider provider);
}
