package com.market2.dao;

import com.market2.pojo.Role;
import com.market2.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface UserDao {
    User getLoginUser(@Param("userCode") String userCode, @Param("userPassword") String userPassword);

    void updatePsw(@Param("userId") int userId, @Param("newPsw") String newPsw);

    List<User> getUsers(@Param("userName") String userName, @Param("userRole") Integer userRole);

    List<Role> getRoles();

    Integer getCount(@Param("userName") String userName, @Param("userRole") Integer userRole);

    User getUserById(int id);

    void updateUser(User user);

    void delUser(int id);

    User getUserByCode(String userCode);

    void addUser(User user);
}
