package com.market2.utils;

public class Constants {
    public static final String USER_SESSION = "userSession";
    public static final String ROOT = "/smbms2_springmvc_war";
    public static final int PAGE_SIZE = 10;
}
