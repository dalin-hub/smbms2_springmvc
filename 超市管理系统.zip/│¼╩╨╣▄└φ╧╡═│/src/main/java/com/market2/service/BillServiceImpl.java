package com.market2.service;

import com.market2.dao.BillDao;
import com.market2.pojo.Bill;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BillServiceImpl implements BillService{
    @Autowired
    private BillDao billDao;

    @Override
    public List<Bill> getBills(String productName, Integer providerId, Integer isPayment) {
        return billDao.getBills(productName, providerId, isPayment);
    }

    @Override
    public Bill getBillById(Integer id) {
        return billDao.getBillById(id);
    }

    @Override
    public void updateBill(Bill bill) {
        billDao.updateBill(bill);
    }

    @Override
    public void addBill(Bill bill) {
        billDao.addBill(bill);
    }
}
