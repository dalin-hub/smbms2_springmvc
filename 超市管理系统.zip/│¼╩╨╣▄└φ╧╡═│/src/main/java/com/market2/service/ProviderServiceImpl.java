package com.market2.service;

import com.market2.dao.ProviderDao;
import com.market2.pojo.Provider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProviderServiceImpl implements ProviderService{
    @Autowired
    private ProviderDao providerDao;

    @Override
    public List<Provider> getProviders(String proCode, String proName) {
        return providerDao.getProviders(proCode, proName);
    }

    @Override
    public Provider getProviderById(Integer proId) {
        return providerDao.getProviderById(proId);
    }

    @Override
    public void updateProvider(Provider provider) {
        providerDao.updateProvider(provider);
    }

    @Override
    public void delProviderById(String proId) {
        providerDao.delProviderById(proId);
    }

    @Override
    public void addProvider(Provider provider) {
        providerDao.addProvider(provider);
    }
}
