package com.market2.service;

import com.market2.pojo.Provider;

import java.util.List;

public interface ProviderService {
    List<Provider> getProviders(String proCode, String proName);

    Provider getProviderById(Integer proId);

    void updateProvider(Provider provider);

    void delProviderById(String proId);

    void addProvider(Provider provider);
}
