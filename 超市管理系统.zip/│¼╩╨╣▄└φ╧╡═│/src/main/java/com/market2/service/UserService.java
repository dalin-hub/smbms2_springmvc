package com.market2.service;

import com.market2.pojo.Role;
import com.market2.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserService {
    User getLoginUser(String userCode, String password);
    void updatePassword(int userId, String newPsw);
    List<User> getUsers(String userName, Integer userRole, int pageIndex, int pageSize);
    List<Role> getRoles();
    int getCount(String userName, Integer userRole);
    User getUserById(int id);
    void updateUser(User user);
    void delUser(int id);
    User getUserByCode(String userCode);

    void addUser(User user);
}
