package com.market2.service;

import com.market2.pojo.Bill;

import java.util.List;

public interface BillService {
    List<Bill> getBills(String productName, Integer providerId, Integer isPayment);

    Bill getBillById(Integer id);

    void updateBill(Bill bill);

    void addBill(Bill bill);
}
