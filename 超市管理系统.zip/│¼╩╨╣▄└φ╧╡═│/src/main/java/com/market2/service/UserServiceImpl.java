package com.market2.service;

import com.market2.dao.UserDao;
import com.market2.pojo.Role;
import com.market2.pojo.User;
import com.market2.utils.MybatisUtil;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    @Autowired
    private SqlSessionFactory sqlSessionFactory;

    @Override
    public User getLoginUser(String userCode, String password){
        User user = userDao.getLoginUser(userCode, password);
        return user;
    }

    @Override
    public void updatePassword(int userId, String newPsw) {
        userDao.updatePsw(userId, newPsw);
    }

    @Override
    public List<User> getUsers(String userName, Integer userRole, int pageIndex, int pageSize) {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        Map map = new HashMap();
        map.put("userName", userName);
        map.put("userRole", userRole);
        List<User> users = sqlSession.selectList("com.market2.dao.UserDao.getUsers", map, new RowBounds((pageIndex - 1) * pageSize, pageSize));
        sqlSession.close();
        return users;
    }

    @Override
    public List<Role> getRoles() {
        return userDao.getRoles();
    }

    @Override
    public int getCount(String userName, Integer userRole) {
        Integer count = userDao.getCount(userName, userRole);
        return count;
    }

    @Override
    public User getUserById(int id) {
        User userById = userDao.getUserById(id);
        return userById;
    }

    @Override
    public void updateUser(User user) {
        userDao.updateUser(user);
    }

    @Override
    public void delUser(int id) {
        userDao.delUser(id);
    }

    @Override
    public User getUserByCode(String userCode) {
        return userDao.getUserByCode(userCode);
    }

    @Override
    public void addUser(User user) {
        userDao.addUser(user);
    }


    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }
}
