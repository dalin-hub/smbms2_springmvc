package com.market2.filter;

import com.market2.pojo.User;
import com.market2.utils.Constants;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PriorityInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        User user = (User) request.getSession().getAttribute(Constants.USER_SESSION);
        if (user != null){
            return true;
        }
        else {
            response.sendRedirect(Constants.ROOT + "/login");
            return false;
        }
    }
}
