package com.market2.controller;

import com.alibaba.fastjson2.JSONArray;
import com.alibaba.fastjson2.JSONFactory;
import com.alibaba.fastjson2.JSONObject;
import com.alibaba.fastjson2.JSONWriter;
import com.market2.pojo.Provider;
import com.market2.pojo.Role;
import com.market2.pojo.User;
import com.market2.service.ProviderService;
import com.market2.service.UserService;
import com.market2.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/jsp")
public class JspController {
    @Autowired
    private UserService userService;

    @Autowired
    private ProviderService providerService;

//    直接在参数这里写注解得到session的东西
    @RequestMapping("/logout.do")
    public String logout(HttpServletRequest request){
        request.getSession().removeAttribute(Constants.USER_SESSION);
        return "redirect: " + Constants.ROOT + "/login";
    }

    @RequestMapping("/frame")
    public String getFrame(){
        return "frame";
    }

    @RequestMapping("/pwdmodify")
    public String getPwdModifyPage(){
        System.out.println("pwdmodify");
        return "pwdmodify";
    }


    @RequestMapping("/user.do")
    public void validatePsw(@RequestParam("method") String method,
                            @RequestParam(value = "oldpassword", required = false) String oldPassword,
                            @RequestParam(value = "newpassword", required = false) String newPsw,
                            @RequestParam(value = "rnewpassword", required = false) String rNewPsw,
                            @RequestParam(value = "uid", required = false) String uid,
                            @RequestParam(value = "gender", required = false) Integer gender,
                            @RequestParam(value = "userName", required = false) String userName,
                            @RequestParam(value = "phone", required = false) String phone,
                            @RequestParam(value = "address", required = false) String address,
                            @RequestParam(value = "userRole", required = false) Integer userRole,
                            @RequestParam(value = "userCode", required = false) String userCode,
                            @SessionAttribute(Constants.USER_SESSION) User user,
                            HttpServletRequest req,
                            HttpServletResponse resp) throws IOException {
        //    验证旧密码是否正确
        if (method.equals("pwdmodify")){
            resp.setContentType("application/json");
            Map map = new HashMap();
            if (user == null){
                map.put("result", "sessionerror");
                resp.getWriter().write(new JSONObject(map).toJSONString());
                return;
            }

            String truePsw = user.getUserPassword();
            if (oldPassword.equals("")){
                map.put("result", "error");
                resp.getWriter().write(new JSONObject(map).toJSONString());
            }else if (oldPassword.equals(truePsw)) {
                map.put("result", "true");
                resp.getWriter().write(new JSONObject(map).toJSONString());
            }else {
                map.put("result", "false");
                resp.getWriter().write(new JSONObject(map).toJSONString());
            }
        } else if (method.equals("savepwd")) {
//            保存新密码，并跳转到frame页面
            userService.updatePassword(user.getId(), newPsw);
            user.setUserPassword(newPsw);
            req.getSession().setAttribute(Constants.USER_SESSION, user);
            resp.sendRedirect("frame");
        }else if (method.equals("query")){
            //    用户管理页面，只有系统管理员能进入
            if (user.getUserRole() != 1){
                resp.sendRedirect("frame");
                return;
            }else {
//                重定向到userList请求
                resp.sendRedirect("userList");
            }
        }else if (method.equals("view")){
//            重定向到userView请求，使用restful风格
            String uid2 = req.getParameter("uid");
            resp.sendRedirect("userView/" + uid);
        }else if (method.equals("modify")){

            String uid2 = req.getParameter("uid");
            resp.sendRedirect("userModify/" + uid);
        }else if (method.equals("getrolelist")){
//            一个ajax请求，得到roleList，直接设置resp响应就行
            resp.setCharacterEncoding("utf-8");
            resp.setContentType("application/json");
            List<Role> roles = userService.getRoles();
            resp.getWriter().write(new JSONArray(roles).toJSONString());
        }else if (method.equals("modifyexe")){
            User user1 = new User();
            Integer id = Integer.parseInt(uid);
            user1.setId(id);
            user1.setUserName(userName);
            user1.setGender(gender);
            user1.setAddress(address);
            user1.setUserRole(userRole);
            user1.setPhone(phone);
            userService.updateUser(user1);
            resp.sendRedirect("userList");
        }else if (method.equals("deluser")){
            Integer id = Integer.parseInt(uid);
            userService.delUser(id);
            Map map = new HashMap();
            map.put("delResult", "true");
            resp.getWriter().write(new JSONObject(map).toJSONString());
        }else if (method.equals("ucexist")){
            resp.setContentType("application/json");
            User userByCode = userService.getUserByCode(userCode);
            Map map = new HashMap();
            if (userByCode == null){
                map.put("userCode", "noExist");
            }else {
                map.put("userCode", "exist");
            }
            resp.getWriter().write(new JSONObject(map).toJSONString());
        }
    }

    @RequestMapping("/userList")
    public String getUserList(@RequestParam(value = "method", required = false) String method,
                              @RequestParam(value = "queryname", required = false) String userName,
                              @RequestParam(value = "queryUserRole", required = false) Integer userRole,
                              @RequestParam(value = "pageIndex", required = false) Integer pageIndex,
                              Model model){
//        直接通过userService去查满足name和role的用户，因为有动态sql的支持，所以为null也没关系
//        使用rowBound分页

        if (pageIndex == null){
            pageIndex = 1;
        }
        List<User> users = userService.getUsers(userName, userRole, pageIndex, Constants.PAGE_SIZE);
        List<Role> roles = userService.getRoles();
        int totalCount = userService.getCount(userName, userRole);
        int totalPageCount = (totalCount-1) / Constants.PAGE_SIZE + 1;
        model.addAttribute("userList", users);
        model.addAttribute("currentPageNo", pageIndex);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("totalPageCount", totalPageCount);
        model.addAttribute("roleList", roles);
        model.addAttribute("queryUserRole", userRole);

        return "userlist";
    }

    @RequestMapping("/userView/{uid}")
    public String getUserView(@PathVariable("uid") int uid, HttpServletRequest req, Model model){
//        String uid = req.getParameter("uid");
//        int id = Integer.getInteger(uid);
        User user = userService.getUserById(uid);
        model.addAttribute("user", user);
        return "userview";
    }

    @RequestMapping("/userModify/{uid}")
    public String getUserModify(@PathVariable("uid") int uid, HttpServletRequest req, Model model){
        User user = userService.getUserById(uid);
        List<Role> roles = userService.getRoles();

        model.addAttribute("user", user);

        return "usermodify";
    }

    @RequestMapping("/userAdd")
    public String getUserAdd(){
        return "useradd";
    }

    @RequestMapping("/addUser.do")
    public void addUser(@RequestParam("userCode") String userCode,
                        @RequestParam("userName") String userName,
                        @RequestParam("userPassword") String userPassword,
                        @RequestParam("gender") Integer gender,
                        @RequestParam("phone") String phone,
                        @RequestParam("address") String address,
                        @RequestParam("userRole") Integer userRole,
                        HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User user = new User();
        user.setUserRole(userRole);
        user.setAddress(address);
        user.setPhone(phone);
        user.setGender(gender);
        user.setUserPassword(userPassword);
        user.setUserName(userName);
        user.setUserCode(userCode);
        userService.addUser(user);
        resp.sendRedirect("userList");
    }

    @RequestMapping("/provider.do")
    public void getProviderDo(@RequestParam("method") String method,
                              @RequestParam(value = "proid", required = false) String proid,
                              HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (method.equals("query")){
            resp.sendRedirect("providerList");
        }else if (method.equals("view")){
            resp.sendRedirect("proView/" + proid);
        }else if (method.equals("modify")){
            resp.sendRedirect("proModify/" + proid);
        }else if (method.equals("delprovider")){
            resp.sendRedirect("delProvider/" + proid);
        }
    }

    @RequestMapping("/providerList")
    public String getProviderList(@RequestParam(value = "queryProCode", required = false) String proCode,
                                  @RequestParam(value = "queryProName", required = false) String proName,
                                  Model model){
        List<Provider> providers = providerService.getProviders(proCode, proName);
        model.addAttribute("providerList", providers);
        model.addAttribute("queryProCode", proCode);
        model.addAttribute("queryProName", proName);
        return "providerlist";
    }

    @RequestMapping("/proView/{proid}")
    public String getProView(@PathVariable("proid") Integer proId, Model model){
        Provider provider = providerService.getProviderById(proId);
        model.addAttribute("provider", provider);
        return "providerview";
    }

    @RequestMapping("/proModify/{proid}")
    public String getProModify(@PathVariable("proid") Integer proId, Model model){
        Provider provider = providerService.getProviderById(proId);
        model.addAttribute("provider", provider);
        return "providermodify";
    }

    @RequestMapping("/proModifyExe")
    public void getProModifyExe(@RequestParam("proId") Integer proId,
                                  @RequestParam("proCode") String proCode,
                                  @RequestParam("proName") String proName,
                                  @RequestParam("proContact") String proContact,
                                  @RequestParam("proPhone") String proPhone,
                                  @RequestParam("proAddress") String proAddress,
                                  @RequestParam("proFax") String proFax,
                                  @RequestParam("proDesc") String proDesc,
                                  HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Provider provider = new Provider();
        provider.setId(proId);
        provider.setProCode(proCode);
        provider.setProName(proName);
        provider.setProContact(proContact);
        provider.setProPhone(proPhone);
        provider.setProAddress(proAddress);
        provider.setProFax(proFax);
        provider.setProDesc(proDesc);
        providerService.updateProvider(provider);
        resp.sendRedirect("providerList");
    }

    @RequestMapping("/delProvider/{proId}")
    public void delProvider(@PathVariable("proId") String proId,
                            HttpServletRequest req, HttpServletResponse resp) throws IOException {
        providerService.delProviderById(proId);
        resp.setContentType("application/json");
        Map map = new HashMap();
        map.put("delResult", "true");
        resp.getWriter().write(new JSONObject(map).toJSONString());
    }

    @RequestMapping("/providerAdd")
    public String getProviderAdd(Model model){
        return "provideradd";
    }

    @RequestMapping("/doAddProvider")
    public void doAddProvider(@RequestParam("proCode") String proCode,
                            @RequestParam("proName") String proName,
                            @RequestParam("proContact") String proContact,
                            @RequestParam("proPhone") String proPhone,
                            @RequestParam("proAddress") String proAddress,
                            @RequestParam("proFax") String proFax,
                            @RequestParam("proDesc") String proDesc,
                            HttpServletResponse resp) throws IOException {
        Provider provider = new Provider();
//        不设置id，因为id是自增主键
        provider.setProCode(proCode);
        provider.setProName(proName);
        provider.setProContact(proContact);
        provider.setProPhone(proPhone);
        provider.setProAddress(proAddress);
        provider.setProFax(proFax);
        provider.setProDesc(proDesc);
        providerService.addProvider(provider);
        resp.sendRedirect("providerList");
    }
}
