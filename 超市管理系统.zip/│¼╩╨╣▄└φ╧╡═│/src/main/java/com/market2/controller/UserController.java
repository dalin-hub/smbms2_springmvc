package com.market2.controller;

import com.market2.pojo.User;
import com.market2.service.UserService;
import com.market2.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import java.util.List;

@Controller
@SessionAttributes(value = {Constants.USER_SESSION})
@RequestMapping("")
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping("/allUsers")
    public String getUsers(Model model){
        List<User> users = userService.getUsers(null, null, 1, Constants.PAGE_SIZE);
        model.addAttribute("users", users);
        return "allUsers";
    }

    @RequestMapping("/login")
    public String login(){

        return "login";
    }


    @RequestMapping("/login.do")
    public String doLogin(String userCode, String userPassword, Model model){
//        需要调用一个判断登录是否成功的service，如果成功就跳转进入管理页面，如果不成功就回到当前页面
        User loginUser = userService.getLoginUser(userCode, userPassword);
        if (loginUser != null){
//            需要在model中带点东西，转到jsp/frame页面，这样方便管理
            model.addAttribute(Constants.USER_SESSION, loginUser);
            return "redirect: jsp/frame";
        }
        else{
            return "redirect: login";
        }
    }
}
