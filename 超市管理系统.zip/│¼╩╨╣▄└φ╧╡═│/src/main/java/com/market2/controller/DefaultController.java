package com.market2.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;


// 注意静态资源的处理，真的是把我坑惨了，springmvc为了保证安全，禁止直接返回静态资源，非要经过servlet处理一下
// 然后这里面就涉及到default-servlet的配置，路径变量的使用（需要获取文件名），文件的读入和输出（需要写到响应中）
// 还有图片资源的返回（图片资源和文本文件的处理不同）
//@Controller
//@RequestMapping("/static")
public class DefaultController {

//    如何获取路由信息：使用路径变量
//    @RequestMapping("/{fileType}/{fileName}")
    public void getCss(@PathVariable String fileName, @PathVariable String fileType, HttpServletRequest req, HttpServletResponse resp) throws IOException {
        System.out.println(fileName);
        String css = "";
        InputStream inputStream = Files.newInputStream(Paths.get("C:\\#E\\JavaLearn2\\multiThread\\smbms2_springmvc\\src\\main\\webapp\\WEB-INF\\" + fileType + "\\" + fileName));
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
        String tempString;
        while ((tempString = bufferedReader.readLine()) != null){
            css += tempString;
        }

        resp.getWriter().write(css);

    }

//    @RequestMapping("/images/{fileName}")
    public void getImage(@PathVariable String fileName, HttpServletRequest req, HttpServletResponse resp) throws IOException {
        InputStream inputStream = Files.newInputStream(Paths.get("C:\\#E\\JavaLearn2\\multiThread\\smbms2_springmvc\\src\\main\\webapp\\WEB-INF\\images\\" + fileName));
        BufferedImage bufferedImage = ImageIO.read(inputStream);
        ServletOutputStream outputStream = resp.getOutputStream();
        ImageIO.write(bufferedImage, "png", outputStream);
    }


}
