package com.market2.controller;

import com.alibaba.fastjson2.JSONArray;
import com.market2.pojo.Bill;
import com.market2.pojo.Provider;
import com.market2.service.BillService;
import com.market2.service.ProviderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/jsp")
public class BillController {
    @Autowired
    private BillService billService;
    @Autowired
    private ProviderService providerService;

    @RequestMapping("/bill.do")
    public void billDo(@RequestParam("method") String method,
                    @RequestParam(value = "billid", required = false) String billId,
                    HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (method.equals("query")){
            resp.sendRedirect("billList");
        }else if (method.equals("view")){
            resp.sendRedirect("billView/" + billId);
        }else if (method.equals("modify")){
            resp.sendRedirect("billModify/" + billId);
        }else if (method.equals("getproviderlist")){
            resp.sendRedirect("providerListJson");
        }
    }

    @RequestMapping("/billList")
    public String getBillList(@RequestParam(value = "queryProductName", required = false) String productName,
                            @RequestParam(value = "queryProviderId", required = false) Integer providerId,
                            @RequestParam(value = "queryIsPayment", required = false) Integer isPayment,
                            Model model){
        List<Bill> bills = billService.getBills(productName, providerId, isPayment);
        List<Provider> providers = providerService.getProviders(null, null);
        model.addAttribute("queryProductName", productName);
        model.addAttribute("providerList", providers);
        model.addAttribute("queryProviderId", providerId);
        model.addAttribute("queryIsPayment", isPayment);
        model.addAttribute("billList", bills);
        return "billlist";
    }

    @RequestMapping("/billView/{billId}")
    public String getBillView(@PathVariable("billId") Integer id, Model model){
        Bill bill = billService.getBillById(id);
        model.addAttribute("bill", bill);
        return "billview";
    }

    @RequestMapping("/billModify/{billId}")
    public String getBillModify(@PathVariable("billId") Integer id, Model model){
//        这个路由其实不需要传providerName
        Bill bill = billService.getBillById(id);
        model.addAttribute("bill", bill);
        return "billmodify";
    }

    @RequestMapping("/providerListJson")
    public void getProviderListJson(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        List<Provider> providers = providerService.getProviders(null, null);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("utf-8");
        resp.getWriter().write(new JSONArray(providers).toJSONString());
    }

    @RequestMapping("/modifyBill")
    public void getModifyBill(@RequestParam("id") Integer id,
                            @RequestParam("billCode") String billCode,
                            @RequestParam("productName") String productName,
                            @RequestParam("productUnit") String productUnit,
                            @RequestParam("productCount") Float productCount,
                            @RequestParam("totalPrice") Float totalPrice,
                            @RequestParam("providerId") Integer providerId,
                            @RequestParam("isPayment") Integer isPayment,
                            HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Bill bill = new Bill();
        bill.setId(id);
        bill.setBillCode(billCode);
        bill.setProductName(productName);
        bill.setProductUnit(productUnit);
        bill.setProductCount(productCount);
        bill.setTotalPrice(totalPrice);
        bill.setProviderId(providerId);
        bill.setIsPayment(isPayment);
        billService.updateBill(bill);
        resp.sendRedirect("billList");
    }

    @RequestMapping("/billAdd")
    public String getBillAdd(){
        return "billadd";
    }

    @RequestMapping("/addBill")
    public void doAddBill(
                                @RequestParam("billCode") String billCode,
                                @RequestParam("productName") String productName,
                                @RequestParam("productUnit") String productUnit,
                                @RequestParam("productCount") Float productCount,
                                @RequestParam("totalPrice") Float totalPrice,
                                @RequestParam("providerId") Integer providerId,
                                @RequestParam("isPayment") Integer isPayment,
                                HttpServletRequest req, HttpServletResponse resp
    ) throws IOException {
        Bill bill = new Bill();
        bill.setBillCode(billCode);
        bill.setProductName(productName);
        bill.setProductUnit(productUnit);
        bill.setProductCount(productCount);
        bill.setTotalPrice(totalPrice);
        bill.setIsPayment(isPayment);
        bill.setProviderId(providerId);
        billService.addBill(bill);
        resp.sendRedirect("billList");
    }
}
