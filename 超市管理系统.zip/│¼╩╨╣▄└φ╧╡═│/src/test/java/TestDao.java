import com.market2.dao.UserDao;
import com.market2.pojo.Role;
import com.market2.pojo.User;
import com.market2.service.UserService;
import com.market2.utils.Constants;
import com.market2.utils.MybatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.naming.Context;
import java.util.List;

public class TestDao {
    private UserDao userDao;

    private UserService userService;
    public TestDao(){
//        现在这个代码能从spring-dao.xml中拿到userDao说明配置成功了，成功将dao的实现类注册成为bean了
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
        this.userDao = (UserDao) context.getBean("userDao");
        userService = (UserService) context.getBean("UserServiceImpl");
    }

    @Test
    public void testGetLoginUser(){
//        SqlSession sqlSession = MybatisUtil.getSqlSession();
//        UserDao userDao = sqlSession.getMapper(UserDao.class);
        User user = userDao.getLoginUser("admin", "1234567");
        System.out.println(user);
    }

    @Test
    public void testUpdatePsw(){
        userDao.updatePsw(1, "1111111");
        User user = userDao.getLoginUser("admin", "1111111");
        System.out.println(user);
    }

    @Test
    public void testGetRoles(){
        List<Role> roles = userDao.getRoles();
        for (Role role : roles) {
            System.out.println(role);
        }
    }

    @Test
    public void testGetUsers(){
//        动态sql处理不同的输入情况
        List<User> users = userDao.getUsers(null, 3);
        for (User user : users) {
            System.out.println(user);
        }
    }

    @Test
    public void testService(){
        List<User> users = userService.getUsers(null, null, 1, Constants.PAGE_SIZE);
        for (User user : users) {
            System.out.println(user);
        }
    }
}
